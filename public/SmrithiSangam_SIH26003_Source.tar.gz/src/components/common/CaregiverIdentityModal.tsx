import React, { useState } from 'react';
import { Check, Heart, ShieldCheck, Sparkles, User, UserCheck, X } from 'lucide-react';
import { CaregiverAuth, LanguageCode } from '../../types';
import { LANGUAGE_METADATA, TRANSLATIONS } from '../../locales/translations';
import { storageService } from '../../services/storageService';
import { audioService } from '../../services/audioService';

interface CaregiverIdentityModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

export const CaregiverIdentityModal: React.FC<CaregiverIdentityModalProps> = ({
  isOpen,
  onClose,
  selectedLanguage,
  onLanguageChange,
}) => {
  if (!isOpen) return null;

  const currentAuth = storageService.getCaregiverAuth();
  const t = TRANSLATIONS[selectedLanguage];

  const [caregiverName, setCaregiverName] = useState(currentAuth.caregiverName || '');
  const [caregiverPhone, setCaregiverPhone] = useState(currentAuth.caregiverPhone || '');
  const [caregiverRelationship, setCaregiverRelationship] = useState(currentAuth.caregiverRelationship || 'Son / Primary Caregiver');
  const [patientName, setPatientName] = useState(currentAuth.patientName || '');
  const [patientPreferredName, setPatientPreferredName] = useState(currentAuth.patientPreferredName || '');
  const [patientAge, setPatientAge] = useState(currentAuth.patientAge || 74);
  const [patientGender, setPatientGender] = useState<'female' | 'male' | 'other'>(currentAuth.patientGender || 'female');
  const [patientState, setPatientState] = useState(currentAuth.state || 'Assam');
  const [lang, setLang] = useState<LanguageCode>(selectedLanguage);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!caregiverName.trim() || !patientName.trim()) return;

    const updatedAuth: CaregiverAuth = {
      signedIn: true,
      caregiverName: caregiverName.trim(),
      caregiverPhone: caregiverPhone.trim() || '+91 94350 12847',
      caregiverRelationship,
      patientName: patientName.trim(),
      patientPreferredName: patientPreferredName.trim() || patientName.trim(),
      patientAge: Number(patientAge),
      patientGender,
      ashaWorkerName: currentAuth.ashaWorkerName || 'Runu Barman',
      ashaWorkerPhone: currentAuth.ashaWorkerPhone || '+91 98640 44219',
      language: lang,
      state: patientState as any,
    };

    storageService.saveCaregiverAuth(updatedAuth);
    if (lang !== selectedLanguage) {
      onLanguageChange(lang);
    }

    audioService.playVictory();
    const welcome = `${updatedAuth.caregiverName}, your profile for ${updatedAuth.patientPreferredName} is ready.`;
    audioService.speak(welcome, lang);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in zoom-in-95 duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border-2 border-amber-300 text-slate-900 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-amber-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-600 text-white flex items-center justify-center shadow-md">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[11px] font-bold text-amber-800 uppercase tracking-widest block">
                {t.caregiverSignIn} · SIH26003
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-950">
                {t.updateProfile}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 mb-5 leading-relaxed">
          Set your real identity as the primary caregiver and your loved one's real name. All daily activities, vocal greetings in native dialects, memory-assist reminders, and clinical reports will use these actual names.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Caregiver Real Name & Contact */}
          <div className="bg-amber-50/60 rounded-2xl p-4 border border-amber-200 space-y-3">
            <span className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-amber-700" />
              <span>1. Your Identity (Caregiver / ASHA Worker)</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {t.caregiverNameLabel} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Partha / JB / Jitender"
                  value={caregiverName}
                  onChange={(e) => setCaregiverName(e.target.value)}
                  className="w-full text-sm font-semibold py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {t.relationLabel}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Son, Daughter, Grandchild, ASHA"
                  value={caregiverRelationship}
                  onChange={(e) => setCaregiverRelationship(e.target.value)}
                  className="w-full text-sm font-semibold py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {t.phoneLabel} (Used for 1-Tap SOS Emergency Call)
                </label>
                <input
                  type="tel"
                  placeholder="+91 94350 12847"
                  value={caregiverPhone}
                  onChange={(e) => setCaregiverPhone(e.target.value)}
                  className="w-full text-sm font-mono py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Elder Patient's Real Name & Language */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-600 fill-rose-600" />
              <span>2. Elder's Identity & Native Language</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {t.patientNameLabel} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ananya Phukan / Maya Devi"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full text-sm font-semibold py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {t.preferredNameLabel}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Aita Ananya, Maa, Dadi, Mei"
                  value={patientPreferredName}
                  onChange={(e) => setPatientPreferredName(e.target.value)}
                  className="w-full text-sm font-semibold py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Age (Years)
                </label>
                <input
                  type="number"
                  min={50}
                  max={110}
                  value={patientAge}
                  onChange={(e) => setPatientAge(Number(e.target.value))}
                  className="w-full text-sm py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Gender
                </label>
                <select
                  value={patientGender}
                  onChange={(e) => setPatientGender(e.target.value as any)}
                  className="w-full text-sm py-2.5 px-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-amber-500"
                >
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Language Selector written strictly in original native scripts */}
              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Native Language & Script (Written in Original Language)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(Object.keys(LANGUAGE_METADATA) as LanguageCode[]).map((code) => {
                    const meta = LANGUAGE_METADATA[code];
                    const isSelected = lang === code;

                    return (
                      <button
                        key={code}
                        type="button"
                        onClick={() => setLang(code)}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-100 border-amber-600 ring-2 ring-amber-400 font-bold'
                            : 'bg-white border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        <div className="text-sm font-extrabold text-slate-900">
                          {meta.nativeName}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {meta.scriptName}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full min-h-[56px] rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-extrabold text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-900/15 transition-transform active:scale-[0.99] cursor-pointer"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>Save & Apply Real Identity</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
